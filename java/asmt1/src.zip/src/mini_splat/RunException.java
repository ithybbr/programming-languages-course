package mini_splat;

public class RunException extends Exception {

    public RunException(String msg) {
        super(msg);
    }
}
