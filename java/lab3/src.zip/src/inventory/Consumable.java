package inventory;

abstract public class Consumable extends Item{
    
}
