package inventory;

abstract public class Item {
    
}
