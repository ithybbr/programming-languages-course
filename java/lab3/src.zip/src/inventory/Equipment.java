package inventory;

abstract public class Equipment extends Item{
    
}
