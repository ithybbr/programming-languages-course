package src;

public class Giraffe extends Animal{
    public Giraffe(String name, int weight){
        super(name, weight, "leaves", 300, "grassland", 1500);
    }
}
