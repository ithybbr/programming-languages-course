package src;

public class Tiger extends Animal{
    public Tiger(String name, int weight){
        super(name, weight, "meat", 200, "grassland", 1000);
    }
}
