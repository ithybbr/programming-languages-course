package src;

public class Penguin extends Animal{
    public Penguin(String name, int weight){
        super(name, weight, "fish", 15, "water", 20);
    }
}
